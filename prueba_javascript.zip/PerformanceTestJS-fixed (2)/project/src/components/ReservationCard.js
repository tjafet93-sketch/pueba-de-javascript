import { isAdmin, getSession } from "@/utils";
import { deleteReservation, updateReservation } from "@services/reservation.service";
import { homeController } from "@controllers/home.controller";
import { navigateTo } from "@/router/router";

// Colores de estado para visual rápido
const statusColor = {
  pending: "bg-yellow-100 text-yellow-800",
  approved: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
};

export default function ReservationCard(reservation) {
  const { id, userId, workspace, date, startHour, endHour, reason, status } = reservation;
  const color = statusColor[status] || "bg-gray-100 text-gray-800";
  const currentUser = getSession();
  const isUserOwner = currentUser?.id === userId;
  const canUserEdit = isUserOwner && status === "pending";

  // Añade botones de admin después del render
  setTimeout(() => {
    if (isAdmin()) {
      document.querySelector(`#admin-approve-${id}`)?.addEventListener("click", async () => {
        await updateReservation(id, { status: "approved" });
        homeController();
      });
      document.querySelector(`#admin-reject-${id}`)?.addEventListener("click", async () => {
        await updateReservation(id, { status: "rejected" });
        homeController();
      });
      document.querySelector(`#admin-edit-${id}`)?.addEventListener("click", () => {
        navigateTo(`/edit-reservation?id=${id}`);
      });
      document.querySelector(`#admin-delete-${id}`)?.addEventListener("click", async () => {
        if (confirm("¿Estás seguro de que quieres eliminar esta reserva?")) {
          await deleteReservation(id);
          homeController();
        }
      });
    }

    // Botones para usuarios propietarios de la reserva en estado pending
    if (canUserEdit) {
      document.querySelector(`#user-edit-${id}`)?.addEventListener("click", () => {
        navigateTo(`/edit-reservation?id=${id}`);
      });
      document.querySelector(`#user-cancel-${id}`)?.addEventListener("click", async () => {
        if (confirm("¿Estás seguro de que quieres cancelar esta reserva?")) {
          await deleteReservation(id);
          homeController();
        }
      });
    }
  });

  return `
    <article class="border border-gray-200 rounded-lg p-6 bg-white shadow-md hover:shadow-lg transition">
      <h3 class="font-bold text-lg text-gray-800 mb-3">${workspace}</h3>
      <p class="text-sm text-gray-600 mb-2"><strong class="text-gray-700">Fecha:</strong> ${date}</p>
      <p class="text-sm text-gray-600 mb-2"><strong class="text-gray-700">Horario:</strong> ${startHour} - ${endHour}</p>
      <p class="text-sm text-gray-600 mb-4"><strong class="text-gray-700">Motivo:</strong> ${reason}</p>
      <div class="flex items-center justify-between">
        <span class="inline-block text-xs font-semibold px-3 py-1 rounded-full ${color}">${status.toUpperCase()}</span>
        <div class="flex gap-2">
          ${isAdmin() ? `
            <button id="admin-edit-${id}" class="text-xs px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition font-medium">Editar</button>
            <button id="admin-approve-${id}" class="text-xs px-3 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition font-medium">Aprobar</button>
            <button id="admin-reject-${id}" class="text-xs px-3 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition font-medium">Rechazar</button>
            <button id="admin-delete-${id}" class="text-xs px-3 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition font-medium">Eliminar</button>
          ` : canUserEdit ? `
            <button id="user-edit-${id}" class="text-xs px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition font-medium">Editar</button>
            <button id="user-cancel-${id}" class="text-xs px-3 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition font-medium">Cancelar</button>
          ` : ""}
        </div>
      </div>
    </article>
  `;
}
