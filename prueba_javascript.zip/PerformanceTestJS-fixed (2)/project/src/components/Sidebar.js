import { removeSession } from "@/utils";
import { navigateTo } from "@/router/router";

export default function Sidebar() {
  // Adjunta eventos después de que el HTML se renderice
  setTimeout(() => {
    document.querySelector("#logoutBtn")?.addEventListener("click", () => {
      removeSession();
      navigateTo("/");
    });
  });

  return `
    <aside class="w-64 bg-gradient-to-b from-slate-900 to-slate-800 text-white min-h-screen p-6 flex flex-col gap-6 shadow-xl">
      <h2 class="text-2xl font-bold text-center border-b border-slate-700 pb-4">Reservas</h2>
      <nav class="flex flex-col gap-3">
        <a href="/home" data-link class="px-4 py-3 bg-blue-600 rounded-lg hover:bg-blue-700 transition font-medium shadow-md">Inicio</a>
        <a href="/reservations" data-link class="px-4 py-3 bg-indigo-600 rounded-lg hover:bg-indigo-700 transition font-medium shadow-md">Reservas</a>
      </nav>
      <button id="logoutBtn" class="mt-auto text-left px-4 py-3 text-white bg-red-600 hover:bg-red-700 rounded-lg transition font-medium shadow-md">
        Cerrar sesión
      </button>
    </aside>
  `;
}
