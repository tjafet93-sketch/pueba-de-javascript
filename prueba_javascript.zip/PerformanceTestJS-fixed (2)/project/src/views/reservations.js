import Sidebar from "@components/Sidebar";
import { reservationController } from "@controllers/reservation.controller";

// Vista con el formulario para crear una reserva
export default function reservationsView() {
  setTimeout(() => reservationController());

  return `
    <div class="flex">
      ${Sidebar()}
      <main class="flex-1 p-8 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
        <div class="mb-8">
          <h1 class="text-3xl font-bold text-gray-800 mb-2">Nueva Reserva</h1>
          <p class="text-gray-600">Completa el formulario para reservar un espacio</p>
        </div>
        <form id="reservationForm" class="bg-white p-8 rounded-lg shadow-lg border border-gray-200 max-w-2xl flex flex-col gap-6">

          <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">Espacio</label>
            <input type="text" name="workspace" placeholder="Ej: Sala A" required
              class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>

          <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">Fecha</label>
            <input type="date" name="date" required class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>

          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-sm font-semibold text-gray-700 mb-2">Hora inicio</label>
              <input type="time" name="startHour" required class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
            </div>
            <div>
              <label class="block text-sm font-semibold text-gray-700 mb-2">Hora fin</label>
              <input type="time" name="endHour" required class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
            </div>
          </div>

          <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">Motivo</label>
            <input type="text" name="reason" placeholder="Ej: Sprint Planning" required
              class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>

          <button type="submit" class="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-lg hover:from-green-700 hover:to-green-800 font-semibold transition shadow-lg mt-4">
            Crear Reserva
          </button>
        </form>
      </main>
    </div>
  `;
}
