import Sidebar from "@components/Sidebar";
import { getSession } from "@/utils";
import { homeController } from "@controllers/home.controller";

// Vista principal con panel según el rol del usuario
export default function homeView() {
  const user = getSession();

  setTimeout(() => homeController());

  return `
    <div class="flex">
      ${Sidebar()}
      <main class="flex-1 p-8 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">

        <div class="mb-8 bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-600">
          <h1 class="text-3xl font-bold text-gray-800">Bienvenido, ${user?.name}</h1>
          <p class="text-sm text-gray-600 mt-2">Rol: <span class="font-semibold text-blue-600">${user?.role === 'admin' ? 'Administrador' : 'Usuario'}</span></p>
        </div>

        <section class="bg-white border border-blue-200 rounded-lg p-6 mb-6 shadow-md">
          <p class="text-gray-700">${user?.role === "admin"
            ? `<strong class="text-blue-600">Permisos de Admin:</strong> Ves todas las reservas y puedes aprobar, rechazar o eliminar.`
            : `<strong class="text-blue-600">Tu vista:</strong> Ves únicamente tus reservas.`
          }</p>
        </section>

        <section class="bg-white border border-gray-200 rounded-lg p-6 shadow-md">
          <h2 class="text-2xl font-bold mb-6 text-gray-800">Reservas</h2>
          <div id="reservationsContainer" class="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <p class="text-gray-400 col-span-full text-center py-12">Cargando...</p>
          </div>
        </section>

      </main>
    </div>
  `;
}
