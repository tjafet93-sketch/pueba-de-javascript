import Sidebar from "@components/Sidebar";
import { editReservationController, getReservationById, canEditReservation } from "@controllers/editReservation.controller";

// Vista con el formulario para editar una reserva
export default function editReservationView() {
  const url = new URL(window.location);
  const reservationId = url.searchParams.get("id");

  setTimeout(async () => {
    if (!reservationId) return;

    const canEdit = await canEditReservation(reservationId);
    if (!canEdit) {
      alert("No tienes permiso para editar esta reserva");
      window.history.back();
      return;
    }

    const reservation = await getReservationById(reservationId);
    if (reservation) {
      editReservationController(reservationId);
    }
  });

  return `
    <div class="flex">
      ${Sidebar()}
      <main class="flex-1 p-8 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
        <div class="mb-8">
          <h1 class="text-3xl font-bold text-gray-800 mb-2">Editar Reserva</h1>
          <p class="text-gray-600">Actualiza los detalles de la reserva</p>
        </div>
        <form id="editReservationForm" class="bg-white p-8 rounded-lg shadow-lg border border-gray-200 max-w-2xl flex flex-col gap-6">

          <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">Espacio</label>
            <input type="text" name="workspace" placeholder="Ej: Sala A" required
              class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>

          <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">Fecha</label>
            <input type="date" name="date" required class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>

          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-sm font-semibold text-gray-700 mb-2">Hora inicio</label>
              <input type="time" name="startHour" required class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
            </div>
            <div>
              <label class="block text-sm font-semibold text-gray-700 mb-2">Hora fin</label>
              <input type="time" name="endHour" required class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
            </div>
          </div>

          <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">Motivo</label>
            <input type="text" name="reason" placeholder="Ej: Sprint Planning" required
              class="border border-gray-300 w-full px-4 py-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>

          <div class="flex gap-4 mt-4">
            <button type="submit" class="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-3 rounded-lg hover:from-blue-700 hover:to-blue-800 font-semibold transition shadow-lg flex-1">
              Guardar Cambios
            </button>
            <button type="button" onclick="window.history.back()" class="bg-gray-400 text-white px-6 py-3 rounded-lg hover:bg-gray-500 font-semibold transition shadow-lg flex-1">
              Cancelar
            </button>
          </div>
        </form>
      </main>
    </div>
  `;
}
