import { loginController } from "@controllers/login.controller";

// Vista de login con formulario de autenticación
export default function loginView() {
  setTimeout(() => loginController());

  return `
    <div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
      <div class="bg-white rounded-lg shadow-2xl p-8 w-96 border border-blue-100">
        <h1 class="text-3xl font-bold mb-2 text-center text-gray-800">Iniciar Sesión</h1>
        <p class="text-center text-gray-500 mb-6 text-sm">Accede a tu cuenta</p>
        
        <form id="loginForm" class="flex flex-col gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Correo</label>
            <input type="email" name="email" placeholder="tu@correo.com" required
              class="border border-gray-300 px-4 py-3 rounded-lg w-full focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Contraseña</label>
            <input type="password" name="password" placeholder="Contraseña" required
              class="border border-gray-300 px-4 py-3 rounded-lg w-full focus:ring-2 focus:ring-blue-500 focus:border-transparent transition" />
          </div>
          
          <button type="submit" class="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed">
            Ingresar
          </button>
        </form>
      </div>
    </div>
  `;
}
