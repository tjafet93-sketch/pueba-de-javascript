import { updateReservation, getReservations } from "@services/reservation.service";
import { navigateTo } from "@/router/router";
import { getSession, isAdmin } from "@/utils";

// Obtiene una reserva por ID
export const getReservationById = async (id) => {
  const reservations = await getReservations();
  return reservations.find((r) => r.id === id);
};

// Verifica si el usuario actual puede editar la reserva
export const canEditReservation = async (reservationId) => {
  const user = getSession();
  const reservation = await getReservationById(reservationId);

  if (!reservation || !user) return false;

  // Admin puede editar cualquier reserva
  if (isAdmin()) return true;

  // Usuario normal solo puede editar la suya si está en pending
  return user.id === reservation.userId && reservation.status === "pending";
};

// Maneja el submit del formulario de edición de reserva
export const editReservationController = async (reservationId) => {
  const form = document.querySelector("#editReservationForm");

  // Carga los datos de la reserva en el formulario
  const reservation = await getReservationById(reservationId);
  if (reservation) {
    form.workspace.value = reservation.workspace;
    form.date.value = reservation.date;
    form.startHour.value = reservation.startHour;
    form.endHour.value = reservation.endHour;
    form.reason.value = reservation.reason;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
      workspace: form.workspace.value.trim(),
      date: form.date.value,
      startHour: form.startHour.value,
      endHour: form.endHour.value,
      reason: form.reason.value.trim(),
    };

    try {
      await updateReservation(reservationId, data);
      alert("Reserva actualizada exitosamente");
      navigateTo("/home");
    } catch {
      alert("Error al actualizar la reserva");
    }
  });
};
