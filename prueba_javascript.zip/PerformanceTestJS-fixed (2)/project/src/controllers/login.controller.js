import { saveSession, showNotification } from "@/utils";
import { navigateTo } from "@/router/router";
import { http } from "@/api/http";

// Maneja el submit del formulario de login
export const loginController = () => {
  const form = document.querySelector("#loginForm");
  const submitBtn = form?.querySelector("button[type='submit']");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = form.email.value.trim();
    const password = form.password.value.trim();

    // Validación front-end
    if (!email || !password) {
      showNotification("Por favor completa todos los campos", "warning");
      return;
    }

    if (!email.includes("@")) {
      showNotification("Por favor ingresa un correo válido", "warning");
      return;
    }

    // Deshabilitar botón durante la carga
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Autenticando...";
    }

    try {
      const users = await http.get(`/users?email=${email}&password=${password}`);

      if (!users || users.length === 0) {
        showNotification("Correo o contraseña incorrectos", "error");
        // Limpiar campos de contraseña
        form.password.value = "";
        return;
      }

      // Guarda solo los datos necesarios en sesión
      const userData = { 
        id: users[0].id, 
        name: users[0].name, 
        email: users[0].email,
        role: users[0].role 
      };
      
      saveSession(userData);
      showNotification(`Bienvenido ${userData.name}`, "success");
      
      // Esperar a que la notificación sea visible antes de navegar
      setTimeout(() => {
        navigateTo("/home");
      }, 500);
    } catch (error) {
      console.error("Error de autenticación:", error);
      showNotification("Error conectando con el servidor. Intenta más tarde.", "error");
    } finally {
      // Rehabilitar botón
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = "Ingresar";
      }
    }
  });
};
